<?php

namespace App\Filament\Resources\EngagementsResource\Pages;

use App\Filament\Resources\EngagementsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateEngagements extends CreateRecord
{
    protected static string $resource = EngagementsResource::class;
}
