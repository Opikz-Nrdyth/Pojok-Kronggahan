<?php

namespace App\Http\Controllers;

class LiveChat extends Controller
{
    public function LiveChat()
    {

        return view('live-chat');
    }
}
