<div class="container-about">
    <div class="title">
        <h2>About</h2>
    </div>
    <section id="about">
        {!! $website['content'] !!}
    </section>
</div>
