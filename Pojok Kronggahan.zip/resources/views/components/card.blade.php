<a href="{{ $route }}">
    <div class="card">
        <img src="{{ asset('public/storage/' . $thumbnail) }}" alt="{{ $title }}">
        <div class="card-title">{{ $title }}</div>
    </div>
</a>
