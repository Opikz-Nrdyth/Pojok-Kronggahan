<div class="container-perhatian">
    <div class="title">
        <h2>Perhatian</h2>
    </div>
    <section id="perhatian">
        {!! $website['content'] !!}
    </section>
</div>
