<a href="<?php echo e($route); ?>">
    <div class="card">
        <img src="<?php echo e(asset('public/storage/' . $thumbnail)); ?>" alt="<?php echo e($title); ?>">
        <div class="card-title"><?php echo e($title); ?></div>
    </div>
</a>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/components/card.blade.php ENDPATH**/ ?>