<div class="container-search" style="display: none">
    <div class="grup-input">
        <button><i class="fa-solid fa-magnifying-glass"></i></button>
        <input type="text" id="search">
    </div>
</div>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/components/search.blade.php ENDPATH**/ ?>