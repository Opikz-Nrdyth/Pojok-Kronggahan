<div class="container-search" style="display: block">
    <form wire:submit.prevent="searchHandle">
        <div class="grup-input">
            <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            <input type="text" id="search" wire:model="fieldInput">
        </div>
    </form>
    <div class="list-search">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $newsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="a-not-link" href="/news/<?php echo e($news['id']); ?>">
                <div class="item-search" wire:key="news-<?php echo e($news['id']); ?>">
                    <h2 class="title"><?php echo e($news['title']); ?></h2>
                    <div class="descriptions"><?php echo e($news['description']); ?></div>
                    <div class="attribute">
                        <div class="tag"><?php echo e($news['categories']); ?></div>
                        <div class="date"><?php echo e($news['date']); ?></div>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

</div>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/livewire/search.blade.php ENDPATH**/ ?>