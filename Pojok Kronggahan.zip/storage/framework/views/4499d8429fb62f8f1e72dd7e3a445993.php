<div class="container-chat container">
    <div>
        <div class="title">
            <h2><?php echo e($title); ?></h2>
            <a href="live-chat"><i class="fa-solid fa-arrow-up-right-from-square"></i></a>
        </div>
        <div class="messages">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal97a952fb2d932d8deca0f6ec38452f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97a952fb2d932d8deca0f6ec38452f95 = $attributes; } ?>
<?php $component = App\View\Components\LiveChat::resolve(['card' => $message] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('live-chat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LiveChat::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97a952fb2d932d8deca0f6ec38452f95)): ?>
<?php $attributes = $__attributesOriginal97a952fb2d932d8deca0f6ec38452f95; ?>
<?php unset($__attributesOriginal97a952fb2d932d8deca0f6ec38452f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97a952fb2d932d8deca0f6ec38452f95)): ?>
<?php $component = $__componentOriginal97a952fb2d932d8deca0f6ec38452f95; ?>
<?php unset($__componentOriginal97a952fb2d932d8deca0f6ec38452f95); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
    <!-- Input Area -->
    <div class="input-area">
        <form wire:submit.prevent="sendMessage" class="input-form">
            <!--[if BLOCK]><![endif]--><?php if($title == 'service'): ?>
                <div class="input-file">
                    <input type="file" wire:model="attachment" id="file-upload" class="file-input">
                    <label for="file-upload" class="file-label">Input File</label>
                    <!--[if BLOCK]><![endif]--><?php if($attachment): ?>
                        <div class="file-name"><?php echo e($attachment->getClientOriginalName()); ?></div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <div class="input-group">
                <div class="emoji-picker">
                    <button type="button" class="emoji-button" onclick="toggleEmojiPicker()">😀</button>
                    <div class="emoji-list hidden" id="emojiPicker">
                        <button type="button" class="emoji-item" onclick="addEmoji('😀')">😀</button>
                        <button type="button" class="emoji-item" onclick="addEmoji('😂')">😂</button>
                        <button type="button" class="emoji-item" onclick="addEmoji('😡')">😡</button>
                        <button type="button" class="emoji-item" onclick="addEmoji('😱')">😱</button>
                        <button type="button" class="emoji-item" onclick="addEmoji('😴')">😴</button>
                        <button type="button" class="emoji-item" onclick="addEmoji('🗿')">🗿</button>
                        <button type="button" class="emoji-item" onclick="addEmoji('👍')">👍</button>
                        <button type="button" class="emoji-item" onclick="addEmoji('👎')">👎</button>
                        <button type="button" class="emoji-item" onclick="addEmoji('❤️')" id="loveEmoji">❤️</button>
                        <!-- Add more emojis as needed -->
                    </div>
                </div>
                <div class="input-wrapper">
                    <input type="text" wire:model="newMessage" placeholder="Type your message..." class="text-input"
                        id="messageInput">
                </div>

                <button type="submit" class="send-button">
                    Send
                </button>
            </div>
        </form>
    </div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            const chatContainer = document.querySelector('.messages');

            function scrollToBottom() {
                chatContainer.scrollTop = chatContainer.scrollHeight;
            }
            scrollToBottom()

            document.addEventListener("DOMContentLoaded", function(event) {
                Echo.channel('chat.<?php echo e($room->id); ?>')
                    .listen('.message.sent', (e) => {
                        scrollToBottom();
                        window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('loadMessage', e.message);
                    });
            });

            function toggleEmojiPicker() {
                const emojiPicker = document.getElementById('emojiPicker');
                emojiPicker.classList.toggle('hidden');
            }

            function addEmoji(emoji) {
                const messageInput = document.getElementById('messageInput');
                messageInput.value += emoji;
                toggleEmojiPicker();
                if (emoji === '❤️') {
                    const surprise = document.getElementById('surprise');
                    surprise.classList.remove('hidden');
                    setTimeout(() => {
                        surprise.classList.add('hidden');
                    }, 3000);
                }
            }
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/livewire/live-chat.blade.php ENDPATH**/ ?>