<div class="container-perhatian">
    <div class="title">
        <h2>Perhatian</h2>
    </div>
    <section id="perhatian">
        <?php echo $website['content']; ?>

    </section>
</div>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/components/perhatian.blade.php ENDPATH**/ ?>