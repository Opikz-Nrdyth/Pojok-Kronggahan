<div <?php echo e($attributes->class(['flex gap-x-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\vendor\filament\forms\src\/../resources/views/components/rich-editor/toolbar/group.blade.php ENDPATH**/ ?>