<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .chat-container {
            display: flex;
            height: 70vh;
            gap: 16px;
        }

        .rooms-sidebar {
            width: 25%;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 16px;
        }

        .rooms-title {
            font-weight: 500;
            margin-bottom: 16px;
        }

        .rooms-list {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .room-button {
            width: 100%;
            text-align: left;
            padding: 8px;
            border-radius: 4px;
            background: transparent;
            border: none;
            cursor: pointer;
            transition: background 0.2s;
        }

        .room-button:hover {
            background: #f9f9f9;
        }

        .active-room {
            background: #eef7ff;
        }

        .room-name {
            font-weight: 500;
        }

        .room-time {
            font-size: 12px;
            color: #6b7280;
        }

        .chat-area {
            flex: 1;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
        }

        .chat-wrapper {
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .messages {
            flex: 1;
            padding: 16px;
            overflow-y: auto;
        }

        .message {
            margin-bottom: 16px;
            max-width: 70%;
        }

        .message-own {
            margin-left: auto;
        }

        .message-content {
            padding: 12px;
            border-radius: 8px;
            font-size: 14px;
        }

        .message-own-content {
            background: #e0f7fa;
        }

        .message-other-content {
            background: #f3f4f6;
        }

        .message-user {
            font-weight: 500;
            font-size: 12px;
        }

        .message-body {
            margin-top: 4px;
        }

        .message-file {
            color: #0288d1;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .message-file:hover {
            text-decoration: underline;
        }

        .message-time {
            margin-top: 4px;
            font-size: 10px;
            color: #6b7280;
        }

        .input-area {
            border-top: 1px solid #e5e7eb;
            padding: 16px;
        }

        .input-form {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .input-file {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .file-input {
            display: none;
        }

        .file-label {
            cursor: pointer;
            color: #0288d1;
            font-size: 14px;
        }

        .file-name {
            font-size: 12px;
            color: #6b7280;
        }

        .input-box {
            display: flex;
            gap: 8px;
        }

        .text-input {
            flex: 1;
            padding: 8px;
            border: 1px solid #e5e7eb;
            border-radius: 4px;
            font-size: 14px;
        }

        .send-button {
            background: #0288d1;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .send-button:hover {
            background: #0277bd;
        }

        .no-chat {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: #6b7280;
        }
    </style>
    <div class="chat-container">
        <!-- Rooms Sidebar -->
        <div class="rooms-sidebar">
            <h3 class="rooms-title">Customer Service Chats</h3>
            <div class="rooms-list" wire:poll.30s="fetchRooms">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button wire:click="selectRoom(<?php echo e($room->id); ?>)"
                        class="room-button <?php echo e($currentRoom?->id === $room->id ? 'active-room' : ''); ?>">
                        <div class="room-name"><?php echo e($room->user?->name ?? 'Anonymous'); ?></div>
                        <div class="room-time">
                            <?php echo e($room->messages->last()?->created_at->diffForHumans() ?? 'No messages'); ?>

                        </div>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <!-- Chat Area -->
        <div class="chat-area">
            <!--[if BLOCK]><![endif]--><?php if($currentRoom): ?>
                <div class="chat-wrapper">
                    <!-- Messages -->
                    <div class="messages">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="message <?php echo e($message->user_id === auth()->id() ? 'message-own' : ''); ?>">
                                <div
                                    class="message-content <?php echo e($message->user_id === auth()->id() ? 'message-own-content' : 'message-other-content'); ?>">
                                    <div class="message-user"><?php echo e($message->user->name); ?></div>
                                    <div class="message-body">
                                        <!--[if BLOCK]><![endif]--><?php if($message->file_path): ?>
                                            <img src="<?php echo e(config('app.url')); ?>/public/storage/<?php echo e($message->file_path); ?>"
                                                alt="<?php echo e($message->file_path); ?>" width="100%">
                                            <a href="<?php echo e(Storage::url($message->file_path)); ?>" target="_blank"
                                                class="message-file">
                                                <span class="file-icon"></span>
                                                <?php echo e($message->file_name); ?>

                                            </a>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php echo e($message->message); ?>

                                    </div>
                                    <div class="message-time"><?php echo e($message->created_at->format('H:i')); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Input Area -->
                    <div class="input-area">
                        <form wire:submit="sendMessage" class="input-form">
                            <div class="input-file">
                                <input type="file" wire:model="attachment" id="file-upload" class="file-input">
                                <label for="file-upload" class="file-label">Upload File</label>
                                <!--[if BLOCK]><![endif]--><?php if($attachment): ?>
                                    <div class="file-name"><?php echo e($attachment->getClientOriginalName()); ?></div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div class="input-box">
                                <input type="text" wire:model="newMessage" placeholder="Type your message..."
                                    class="text-input">
                                <button type="submit" class="send-button">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div class="no-chat">Select a chat to start messaging</div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener("DOMContentLoaded", function(event) {
                const chatContainer = document.querySelector('.messages');

                function scrollToBottom() {
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                }

                scrollToBottom()
                <!--[if BLOCK]><![endif]--><?php if($currentRoom): ?>
                    Echo.channel('chat.<?php echo e($currentRoom->id); ?>')
                        .listen('.message.sent', (e) => {
                            scrollToBottom()
                            window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('loadMessage', e.message);
                        });
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/filament/pages/service.blade.php ENDPATH**/ ?>