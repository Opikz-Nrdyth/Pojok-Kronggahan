<div class="container-about">
    <div class="title">
        <h2>About</h2>
    </div>
    <section id="about">
        <?php echo $website['content']; ?>

    </section>
</div>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/components/about.blade.php ENDPATH**/ ?>