<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(1, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        @media (min-width: 768px) {
            .dashboard-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (min-width: 1024px) {
            .dashboard-grid {
                grid-template-columns: repeat(4, 1fr);
            }
        }

        .stats-card {
            position: relative;
            border-radius: 0.5rem;
            border: 1px solid #e5e7eb;
            background-color: white;
            padding: 1rem;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        }

        .stats-content {
            display: flex;
            align-items: center;
        }

        .stats-data {
            flex: 1;
            min-width: 0;
            margin-left: 1.25rem;
        }

        .stats-label {
            font-size: 0.875rem;
            font-weight: 500;
            color: #6b7280;
        }

        .stats-value {
            font-size: 1.5rem;
            font-weight: 600;
            color: #111827;
        }

        .charts-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1rem;
            margin-top: 1.5rem;
        }

        @media (min-width: 1024px) {
            .charts-grid {
                grid-template-columns: repeat(1, 1fr);
            }
        }

        .chart-card {
            position: relative;
            border-radius: 0.5rem;
            border: 1px solid #e5e7eb;
            background-color: white;
            padding: 1rem;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        }

        .chart-title {
            font-size: 1.125rem;
            font-weight: 500;
            color: #111827;
        }

        .chart-container {
            margin-top: 1rem;
            height: 200px;
        }

        .ratio-bar {
            display: flex;
            height: 1rem;
            overflow: hidden;
            border-radius: 9999px;
            background-color: #e5e7eb;
        }

        .ratio-likes {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #22c55e;
            transition: width 0.3s ease;
        }

        .ratio-dislikes {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #ef4444;
            transition: width 0.3s ease;
        }

        .ratio-stats {
            display: flex;
            justify-content: space-between;
            margin-top: 0.5rem;
            font-size: 0.875rem;
        }

        .ratio-likes-text {
            color: #16a34a;
        }

        .ratio-dislikes-text {
            color: #dc2626;
        }

        /* .trend-chart {
            display: flex;
            height: 160px;
            align-items: flex-end;
            gap: 0.5rem;
            padding: 1rem;
            margin-top: 2rem;
        }

        .trend-bar-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100%;
            position: relative;
        }

        .trend-bar {
            width: 100%;
            background-color: #3b82f6;
            transition: height 0.3s ease;
            border-radius: 4px 4px 0 0;
            min-height: 2px;
        }

        .trend-value {
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 12px;
            color: #6b7280;
            white-space: nowrap;
        }

        .trend-date {
            margin-top: 8px;
            text-align: center;
            font-size: 12px;
            color: #6b7280;
            position: absolute;
            bottom: -25px;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
        } */
    </style>

    <div class="dashboard-grid">
        <div class="stats-card">
            <div class="stats-content">
                <div class="stats-data">
                    <div class="stats-label">Total Users</div>
                    <div class="stats-value"><?php echo e($this->getTotalUsers()); ?> Users</div>
                </div>
            </div>
        </div>

        <div class="stats-card">
            <div class="stats-content">
                <div class="stats-data">
                    <div class="stats-label">Total News</div>
                    <div class="stats-value"><?php echo e($this->getTotalNews()); ?> News</div>
                </div>
            </div>
        </div>

        <div class="stats-card">
            <div class="stats-content">
                <div class="stats-data">
                    <div class="stats-label">Total View Hours</div>
                    <div class="stats-value"><?php echo e($this->getTotalEngagements()['viewHours']); ?> Hour</div>
                </div>
            </div>
        </div>

        <div class="stats-card">
            <div class="stats-content">
                <div class="stats-data">
                    <div class="stats-label">Total Clicks</div>
                    <div class="stats-value"><?php echo e($this->getTotalEngagements()['clicks']); ?> Clicks</div>
                </div>
            </div>
        </div>
    </div>

    <div class="charts-grid">
        <div class="chart-card">
            <h3 class="chart-title">Like vs Dislike Ratio</h3>
            <div class="chart-container">
                <?php
                    $engagements = $this->getTotalEngagements();
                    $totalInteractions = $engagements['likes'] + $engagements['dislikes'];
                    $likePercentage = $totalInteractions > 0 ? ($engagements['likes'] / $totalInteractions) * 100 : 0;
                    $dislikePercentage =
                        $totalInteractions > 0 ? ($engagements['dislikes'] / $totalInteractions) * 100 : 0;
                ?>
                <div class="ratio-bar">
                    <div class="ratio-likes" style="width: <?php echo e($likePercentage); ?>%"></div>
                    <div class="ratio-dislikes" style="width: <?php echo e($dislikePercentage); ?>%"></div>
                </div>
                <div class="ratio-stats">
                    <span class="ratio-likes-text">
                        Likes: <?php echo e(number_format($engagements['likes'])); ?> (<?php echo e(number_format($likePercentage, 1)); ?>%)
                    </span>
                    <span class="ratio-dislikes-text">
                        Dislikes: <?php echo e(number_format($engagements['dislikes'])); ?>

                        (<?php echo e(number_format($dislikePercentage, 1)); ?>%)
                    </span>
                </div>
            </div>
        </div>

        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/filament/pages/dashboard.blade.php ENDPATH**/ ?>