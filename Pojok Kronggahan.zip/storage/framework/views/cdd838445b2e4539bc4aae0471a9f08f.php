<div class="footer">
    <div class="row">
        <?php $__currentLoopData = $socialMedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sosmed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($sosmed['url']); ?>" class="brand-icon"><?php echo $sosmed['icon']; ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <div class="row">
        <ul>
            <li><a href="/service">Hubungi kami</a></li>
            <li><a href="#">Layanan Kami</a></li>
            <li><a href="#">Kebijakan Privasi</a></li>
            <li><a href="#">Syarat & Ketentuan</a></li>
        </ul>
    </div>

    <div class="row">
        Hak Cipta © <?php echo e(date('Y')); ?> Pojok Kronggahan - Semua hak dilindungi undang-undang || Dirancang Oleh: Piny
    </div>
</div>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/components/footer.blade.php ENDPATH**/ ?>