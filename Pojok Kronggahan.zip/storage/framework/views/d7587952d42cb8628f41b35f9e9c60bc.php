<!--[if BLOCK]><![endif]--><?php if(Auth::user()): ?>
    <div class="<?php echo e(Auth::user()->name == $card->user->name ? 'container-chat-me' : 'container-chat-all'); ?>">
        <div class="buble-chat">
            <div class="user <?php echo e(Auth::user()->name == $card->user->name ? 'user-me' : ''); ?>">
                <?php if(Auth::user()->name == $card->user->name): ?>
                    <p><?php echo e($card->user->name); ?></p>
                    <div class="profile">
                        <?php echo e(substr($card->user->name, 0, 1)); ?>

                    </div>
                <?php else: ?>
                    <div class="profile">
                        <?php echo e(substr($card->user->name, 0, 1)); ?>

                    </div>
                    <p><?php echo e($card->user->name); ?></p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="chat <?php echo e(Auth::user()->name == $card->user->name ? 'chat-me' : 'chat-all'); ?>">
                <!--[if BLOCK]><![endif]--><?php if($card->file_path): ?>
                    <img src="<?php echo e(config('app.url')); ?>/public/storage/<?php echo e($card->file_path); ?>" alt="<?php echo e($card->file_path); ?>"
                        width="100%">
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <p>
                    <?php echo e($card->message); ?>

                </p>
            </div>
        </div>
    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/components/live-chat.blade.php ENDPATH**/ ?>