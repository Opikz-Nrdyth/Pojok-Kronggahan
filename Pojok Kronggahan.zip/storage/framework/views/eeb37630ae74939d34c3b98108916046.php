<div class="btn-action">
    <button <?php echo e(in_array($newsId['id'], $dislikedIds) ? 'disabled' : ''); ?>

        class="<?php echo e(in_array($newsId['id'], $likedIds) ? 'action-selected' : ''); ?>" wire:click="like">
        <i class="<?php echo e(in_array($newsId['id'], $likedIds) ? 'fa-solid' : 'fa-regular'); ?> fa-thumbs-up"></i>
        <?php echo e($newsId['like']); ?>

    </button>

    <button <?php echo e(in_array($newsId['id'], $likedIds) ? 'disabled' : ''); ?>

        class="<?php echo e(in_array($newsId['id'], $dislikedIds) ? 'action-selected' : ''); ?>" wire:click="dislike">
        <i class="<?php echo e(in_array($newsId['id'], $dislikedIds) ? 'fa-solid' : 'fa-regular'); ?> fa-thumbs-down"></i>
        <?php echo e($newsId['dislike']); ?>

    </button>

</div>
<?php /**PATH D:\Bank Project 25\Des 24\Pojok Kronggahan\resources\views/livewire/news-action.blade.php ENDPATH**/ ?>